const fs = require('fs');
const path = require('path');
const File = require('../models/File');
const User = require('../models/User');

// Upload file
const uploadFile = async (req, res) => {
  try {
    // Get storage from app locals
    const storage = req.app.locals.storage;
    const fileModel = new File(storage);
    
    // Check if file was uploaded
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }
    
    // Validate file type
    const allowedTypes = ['application/pdf', 'video/mp4'];
    if (!allowedTypes.includes(req.file.mimetype)) {
      // Delete the uploaded file
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ 
        message: 'Only PDF and MP4 files are allowed' 
      });
    }
    
    // Validate file size (20MB max)
    if (req.file.size > 20 * 1024 * 1024) {
      // Delete the uploaded file
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ 
        message: 'File size must be less than 20MB' 
      });
    }
    
    // Get privacy setting from request body
    const privacy = req.body.privacy === 'public' ? 'public' : 'private';
    
    // Create file record in database
    const file = await fileModel.create({
      filename: req.file.originalname,
      path: req.file.path,
      size: req.file.size,
      privacy,
      uploadedBy: req.user._id
    });
    
    res.status(201).json({
      _id: file._id,
      filename: file.filename,
      size: file.size,
      privacy: file.privacy,
      uploadedBy: req.user._id,
      createdAt: file.timestamp
    });
  } catch (error) {
    console.error('File upload error:', error);
    
    // Delete the uploaded file if there was an error
    if (req.file && req.file.path) {
      fs.unlinkSync(req.file.path);
    }
    
    res.status(500).json({ message: 'Server error during file upload' });
  }
};

// Get public files
const getPublicFiles = async (req, res) => {
  try {
    // Get storage from app locals
    const storage = req.app.locals.storage;
    const fileModel = new File(storage);
    
    const files = await fileModel.find({ privacy: 'public' });
    
    // Simulate populate for user data
    const filesWithUserData = files.map(file => ({
      ...file,
      uploadedBy: {
        username: 'User' // Simplified for this implementation
      }
    }));
    
    res.json(filesWithUserData);
  } catch (error) {
    console.error('Get public files error:', error);
    res.status(500).json({ message: 'Server error fetching public files' });
  }
};

// Get user's files
const getUserFiles = async (req, res) => {
  try {
    // Get storage from app locals
    const storage = req.app.locals.storage;
    const fileModel = new File(storage);
    
    const files = await fileModel.find({ uploadedBy: req.user._id });
    
    res.json(files);
  } catch (error) {
    console.error('Get user files error:', error);
    res.status(500).json({ message: 'Server error fetching user files' });
  }
};

// Download file
const downloadFile = async (req, res) => {
  try {
    // Get storage from app locals
    const storage = req.app.locals.storage;
    const fileModel = new File(storage);
    
    const fileId = req.params.id;
    
    // Find the file
    const file = await fileModel.findById(fileId);
    
    if (!file) {
      return res.status(404).json({ message: 'File not found' });
    }
    
    // Check permissions
    if (file.privacy === 'private' && 
        file.uploadedBy.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    // Check if file exists on disk
    if (!fs.existsSync(file.path)) {
      return res.status(404).json({ message: 'File not found on disk' });
    }
    
    // Set headers for download
    res.setHeader('Content-Disposition', `attachment; filename="${file.filename}"`);
    res.setHeader('Content-Type', 'application/octet-stream');
    
    // Stream the file
    const fileStream = fs.createReadStream(file.path);
    fileStream.pipe(res);
    
    fileStream.on('error', (err) => {
      console.error('File stream error:', err);
      res.status(500).json({ message: 'Error streaming file' });
    });
  } catch (error) {
    console.error('Download file error:', error);
    res.status(500).json({ message: 'Server error during file download' });
  }
};

// Delete file
const deleteFile = async (req, res) => {
  try {
    // Get storage from app locals
    const storage = req.app.locals.storage;
    const fileModel = new File(storage);
    
    const fileId = req.params.id;
    
    // Find the file
    const file = await fileModel.findById(fileId);
    
    if (!file) {
      return res.status(404).json({ message: 'File not found' });
    }
    
    // Check if user owns the file
    if (file.uploadedBy.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Access denied' });
    }
    
    // Delete file from disk
    if (fs.existsSync(file.path)) {
      fs.unlinkSync(file.path);
    }
    
    // Delete file record from database
    await fileModel.deleteOne({ _id: fileId });
    
    res.json({ message: 'File deleted successfully' });
  } catch (error) {
    console.error('Delete file error:', error);
    res.status(500).json({ message: 'Server error during file deletion' });
  }
};

module.exports = {
  uploadFile,
  getPublicFiles,
  getUserFiles,
  downloadFile,
  deleteFile
};