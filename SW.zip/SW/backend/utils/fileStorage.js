const fs = require('fs');
const path = require('path');

// Ensure data directory exists
const dataDir = path.join(__dirname, '../../data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Storage files
const usersFile = path.join(dataDir, 'users.json');
const filesFile = path.join(dataDir, 'files.json');

// Initialize storage files if they don't exist
if (!fs.existsSync(usersFile)) {
  fs.writeFileSync(usersFile, JSON.stringify([]));
}

if (!fs.existsSync(filesFile)) {
  fs.writeFileSync(filesFile, JSON.stringify([]));
}

// Helper functions
const readData = (filePath) => {
  try {
    const data = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading data file:', error);
    return [];
  }
};

const writeData = (filePath, data) => {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Error writing data file:', error);
    return false;
  }
};

// Generate unique ID
const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

// User storage functions
const getUsers = () => readData(usersFile);

const saveUsers = (users) => writeData(usersFile, users);

const findUser = (query) => {
  const users = getUsers();
  return users.find(user => {
    for (const key in query) {
      if (user[key] !== query[key]) {
        return false;
      }
    }
    return true;
  });
};

const findUserById = (id) => {
  const users = getUsers();
  return users.find(user => user._id === id);
};

const createUser = (userData) => {
  const users = getUsers();
  const newUser = {
    _id: generateId(),
    ...userData,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  users.push(newUser);
  saveUsers(users);
  return newUser;
};

// File storage functions
const getFiles = () => readData(filesFile);

const saveFiles = (files) => writeData(filesFile, files);

const findFiles = (query) => {
  const files = getFiles();
  return files.filter(file => {
    for (const key in query) {
      if (file[key] !== query[key]) {
        return false;
      }
    }
    return true;
  });
};

const findFileById = (id) => {
  const files = getFiles();
  return files.find(file => file._id === id);
};

const createFile = (fileData) => {
  const files = getFiles();
  const newFile = {
    _id: generateId(),
    ...fileData,
    timestamp: new Date().toISOString()
  };
  files.push(newFile);
  saveFiles(files);
  return newFile;
};

const deleteFileRecord = (id) => {
  const files = getFiles();
  const filteredFiles = files.filter(file => file._id !== id);
  return saveFiles(filteredFiles);
};

module.exports = {
  // User functions
  findUser,
  findUserById,
  createUser,
  
  // File functions
  findFiles,
  findFileById,
  createFile,
  deleteFileRecord,
  
  // Utility functions
  generateId
};