const bcrypt = require('bcrypt');

// User model for file-based storage
class User {
  constructor(storage) {
    this.storage = storage;
  }

  // Create a new user
  async create(userData) {
    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(userData.password, salt);
    
    const user = {
      username: userData.username,
      email: userData.email,
      password: hashedPassword
    };

    return this.storage.createUser(user);
  }

  // Find user by email or username
  async findOne(query) {
    return this.storage.findUser(query);
  }

  // Find user by ID
  async findById(id) {
    return this.storage.findUserById(id);
  }

  // Compare password method
  async comparePassword(candidatePassword, hashedPassword) {
    return bcrypt.compare(candidatePassword, hashedPassword);
  }
}

module.exports = User;