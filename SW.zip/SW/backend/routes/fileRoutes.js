const express = require('express');
const multer = require('multer');
const path = require('path');
const { uploadFile, getPublicFiles, getUserFiles, downloadFile, deleteFile } = require('../controllers/fileController');
const auth = require('../middleware/auth');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    // Generate unique filename
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// Upload file route (protected)
router.post('/upload', auth, upload.single('file'), uploadFile);

// Get public files (no auth required)
router.get('/public-files', getPublicFiles);

// Get user's files (protected)
router.get('/my-files', auth, getUserFiles);

// Download file (protected)
router.get('/files/:id/download', auth, downloadFile);

// Delete file (protected)
router.delete('/files/:id', auth, deleteFile);

module.exports = router;