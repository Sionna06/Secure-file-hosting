# Secure File Hosting Application

A secure file hosting web application with authentication.

## Prerequisites

Before running this application, ensure you have:
1. Node.js installed

## Installation

1. Install dependencies:
   ```
   npm install
   ```

## Running the Application

1. Start the backend server:
   ```
   npm start
   ```
   OR
   ```
   node backend/server.js
   ```

2. Access the application through the server:
   Open your browser and go to: http://localhost:3000

## Troubleshooting Connection Issues

If you see "Connection failed! Please make sure...", check:

1. Backend server is running:
   - You should see "Server running on port 3000" in the terminal
   - Test with: http://localhost:3000/api/health

2. You're accessing through the server, NOT file://:
   - ❌ Wrong: Double-clicking HTML files (file://)
   - ✅ Correct: http://localhost:3000

3. Firewall is not blocking connections:
   - Allow Node.js through firewall
   - Allow port 3000

## API Configuration

If your server runs on a different port:
1. Click "⚙️ API Settings" on any page
2. Change the API Base URL
3. Save the settings

## 🚀 Tech Stack

- **Backend**: Node.js + Express
- **Database**: NeDB (No installation required)
- **Authentication**: JWT Token (stored in localStorage)
- **Password hashing**: bcrypt
- **Frontend**: HTML, CSS, Vanilla JavaScript
- **File handling**: Multer

## 📁 Project Structure

```
secure-file-hosting/
├── backend/
│   ├── controllers/
│   ├── middleware/
│   ├── models/
│   └── routes/
├── frontend/
│   ├── styles.css
│   ├── script.js
│   └── HTML files
├── uploads/
├── .env
├── package.json
└── README.md
```

## 🛠️ Setup Instructions

### Prerequisites

1. **Node.js** (v14 or higher)

### Installation Steps

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Start the application**
   ```bash
   npm start
   ```
   
   Or for development with auto-restart:
   ```bash
   npm run dev
   ```

3. **Access the application**
   Open your browser and navigate to:
   ```
   http://localhost:3000
   ```

## 🔐 Authentication

- Users must register and log in to upload files
- JWT tokens are stored in localStorage
- Tokens expire after 7 days

## 📤 File Upload

- Supported formats: PDF (.pdf) and MP4 (.mp4)
- Maximum file size: 20MB
- Privacy options: Public or Private
- Public files can be accessed by anyone
- Private files are only accessible by the owner

## 🌐 Pages

1. **Home Page** (`/`) - Landing page with features
2. **Register** (`/register`) - Create new account
3. **Login** (`/login`) - Log into existing account
4. **Upload** (`/upload`) - Upload new files (requires login)
5. **My Files** (`/my-files`) - View and manage your files (requires login)
6. **Public Downloads** (`/public-downloads`) - Browse public files

## 🔧 API Endpoints

### Authentication
- `POST /api/register` - Register new user
- `POST /api/login` - Login user

### File Management
- `POST /api/upload` - Upload file (requires auth)
- `GET /api/public-files` - Get all public files
- `GET /api/my-files` - Get user's files (requires auth)
- `GET /api/files/:id/download` - Download file (requires auth)
- `DELETE /api/files/:id` - Delete file (requires auth)

## 📝 Notes

- All data is stored locally (no external APIs)
- No hardcoded data - everything comes from the database
- Full error handling throughout the application
- Clean, commented code
- Works offline

## 🐛 Troubleshooting

1. **Port Already in Use**
   - Change the PORT value in `.env` to another available port

2. **File Upload Issues**
   - Check file size (max 20MB)
   - Verify file type (only PDF and MP4 allowed)
   - Ensure the `uploads` directory has write permissions

## 📄 License

This project is licensed under the MIT License.